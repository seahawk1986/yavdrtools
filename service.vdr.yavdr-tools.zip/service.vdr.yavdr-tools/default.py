import sys

if __name__ == "__main__":
	import resources.lib.yavdrtools as service
	service.Main()
