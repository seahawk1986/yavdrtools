import sys

if __name__ == "__main__":
	import ressources.lib.yavdrtools as service
	service.Main()
